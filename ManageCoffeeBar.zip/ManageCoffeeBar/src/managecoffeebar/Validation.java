/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package managecoffeebar;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author MinhHN@fpt.edu.vn
 */
public class Validation {
    Pattern ptn;
    Matcher mt;
    public static final String EMAIL_HOPLE=
            "/^[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?$/i";
    
    public Validation(){
        ptn = Pattern.compile(EMAIL_HOPLE);
    }
    public boolean isMail(final String hex){
        mt = ptn.matcher(hex);
        return mt.matches();
    }
    
    // mã hóa md5 pass
    public String convertHashToString(String text) throws NoSuchAlgorithmException {
        MessageDigest md = MessageDigest.getInstance("MD5");
        byte[] hashInBytes = md.digest(text.getBytes(StandardCharsets.UTF_8));
        StringBuilder sb = new StringBuilder();
        for (byte b : hashInBytes) {
            sb.append(String.format("%02x", b));
        }
        return sb.toString();
    }
    
    public static final String USER_HOPLE= "[a-z0-9_-]{5,12}$";
    public boolean isUsername(final String hex){
        return false;
        
    }
    
}
