package managecoffeebar;

import com.mysql.jdbc.PreparedStatement;
import java.security.NoSuchAlgorithmException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Pattern;
import javax.swing.JOptionPane;

/**
 *
 * @author MinhHN@fpt.edu.vn
 */
public class Login extends javax.swing.JFrame {

    /**
     * Creates new form Login
     */
    public Login() {
        initComponents();

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jDialog1 = new javax.swing.JDialog();
        jPanel1 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        txtUsername = new javax.swing.JTextField();
        txtPassword = new javax.swing.JPasswordField();
        txtCPassword = new javax.swing.JPasswordField();
        txtEmail = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        bntSignUp = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        txtLogin = new javax.swing.JTextField();
        txtPass = new javax.swing.JPasswordField();
        bntLogin = new javax.swing.JButton();
        bntCancle = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        CbbPosition = new javax.swing.JComboBox<>();
        jLabel2 = new javax.swing.JLabel();

        jDialog1.setTitle("SIGN UP");
        jDialog1.setBackground(new java.awt.Color(255, 102, 255));
        jDialog1.setMinimumSize(new java.awt.Dimension(441, 538));
        jDialog1.getContentPane().setLayout(null);

        jPanel1.setBackground(new java.awt.Color(153, 153, 153));
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel1.setLayout(null);

        jLabel8.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
        jLabel8.setText("Username:");
        jPanel1.add(jLabel8);
        jLabel8.setBounds(28, 28, 70, 16);

        jLabel9.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
        jLabel9.setText("Password:");
        jPanel1.add(jLabel9);
        jLabel9.setBounds(28, 84, 61, 16);

        jLabel10.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
        jLabel10.setText("Confirm Pass:");
        jPanel1.add(jLabel10);
        jLabel10.setBounds(28, 140, 80, 16);
        jPanel1.add(txtUsername);
        txtUsername.setBounds(112, 28, 182, 28);
        jPanel1.add(txtPassword);
        txtPassword.setBounds(112, 84, 182, 28);
        jPanel1.add(txtCPassword);
        txtCPassword.setBounds(112, 140, 182, 28);
        jPanel1.add(txtEmail);
        txtEmail.setBounds(112, 187, 182, 28);

        jLabel12.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
        jLabel12.setText("Email:");
        jPanel1.add(jLabel12);
        jLabel12.setBounds(28, 196, 56, 16);

        jDialog1.getContentPane().add(jPanel1);
        jPanel1.setBounds(42, 112, 322, 252);

        jLabel7.setFont(new java.awt.Font("DialogInput", 1, 48)); // NOI18N
        jLabel7.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel7.setText("LOLO");
        jDialog1.getContentPane().add(jLabel7);
        jLabel7.setBounds(112, 28, 196, 56);

        bntSignUp.setText("SIGN UP");
        bntSignUp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bntSignUpActionPerformed(evt);
            }
        });
        jDialog1.getContentPane().add(bntSignUp);
        bntSignUp.setBounds(238, 406, 98, 25);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Management Coffee&Bar");
        setMaximumSize(new java.awt.Dimension(624, 404));
        setMinimumSize(new java.awt.Dimension(624, 404));
        getContentPane().setLayout(null);

        jLabel1.setFont(new java.awt.Font("Dialog", 2, 16)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Username ");
        getContentPane().add(jLabel1);
        jLabel1.setBounds(84, 112, 84, 28);

        jLabel3.setFont(new java.awt.Font("Dialog", 2, 16)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Password");
        getContentPane().add(jLabel3);
        jLabel3.setBounds(84, 196, 84, 28);

        txtLogin.setBackground(new java.awt.Color(0, 0, 0,80));
        txtLogin.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        txtLogin.setForeground(new java.awt.Color(255, 255, 255));
        txtLogin.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        getContentPane().add(txtLogin);
        txtLogin.setBounds(196, 112, 322, 42);

        txtPass.setBackground(new java.awt.Color(0, 0, 0,80));
        txtPass.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        txtPass.setForeground(new java.awt.Color(255, 255, 255));
        txtPass.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        txtPass.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtPassActionPerformed(evt);
            }
        });
        getContentPane().add(txtPass);
        txtPass.setBounds(196, 187, 322, 42);

        bntLogin.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        bntLogin.setText("Login");
        bntLogin.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        bntLogin.setOpaque(false);
        bntLogin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bntLoginActionPerformed(evt);
            }
        });
        getContentPane().add(bntLogin);
        bntLogin.setBounds(210, 294, 84, 28);

        bntCancle.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        bntCancle.setText("Cancle");
        bntCancle.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        bntCancle.setOpaque(false);
        bntCancle.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bntCancleActionPerformed(evt);
            }
        });
        getContentPane().add(bntCancle);
        bntCancle.setBounds(378, 294, 84, 28);

        jLabel5.setFont(new java.awt.Font("DialogInput", 2, 50)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Login Now");
        getContentPane().add(jLabel5);
        jLabel5.setBounds(182, 0, 378, 70);

        jLabel6.setFont(new java.awt.Font("DialogInput", 0, 12)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel6.setText("Create a new account ?");
        jLabel6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel6MouseClicked(evt);
            }
        });
        getContentPane().add(jLabel6);
        jLabel6.setBounds(238, 336, 196, 15);

        CbbPosition.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Employee", "Admin", " " }));
        getContentPane().add(CbbPosition);
        CbbPosition.setBounds(420, 252, 98, 24);

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/picture/Hinhnen-Coffee-17.jpg"))); // NOI18N
        jLabel2.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        getContentPane().add(jLabel2);
        jLabel2.setBounds(-14, -14, 644, 420);

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void bntCancleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bntCancleActionPerformed
        int choice = JOptionPane.showConfirmDialog(this, "Do you want to exit the program ? ", "Your choose", JOptionPane.YES_NO_OPTION);
        if (choice == 0) {
            bntCancle.setText("YES");
            this.dispose();
        }
    }//GEN-LAST:event_bntCancleActionPerformed

    private void bntLoginActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bntLoginActionPerformed
        try {
            Validation obj1 = new Validation();
            String user = txtLogin.getText();
            String pass = obj1.convertHashToString(String.valueOf(txtPass.getPassword()));
            String pos = CbbPosition.getSelectedItem().toString();
            if (!(CbbPosition.getSelectedItem().toString().equals("Employee"))) {
                try {
                    Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/manage_coffee", "root", "admindeptrai@123");
                    PreparedStatement st = (PreparedStatement) conn.prepareStatement("select * from `signup` where Username=? and Password=?");
                    st.setString(1, user);
                    st.setString(2, pass);
                    ResultSet rs = st.executeQuery();

                    if (rs.next()) {
                        JOptionPane.showMessageDialog(this, "Login successful!!!");
                        Management obj = new Management(rs.getNString(1));
                        this.dispose();
                        obj.setVisible(true);

                    } else {
                        JOptionPane.showMessageDialog(this, "Account no exist !!!");
                    }
                } catch (SQLException ex) {
                    Logger.getLogger(Login.class.getName()).log(Level.SEVERE, null, ex);
                }

            } else {
                try {
                    Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/manage_coffee", "root", "admindeptrai@123");
                    PreparedStatement st = (PreparedStatement) conn.prepareStatement("select * from `informationnv` where `Tài khoản`=? and `Mật khẩu`=?");
                    st.setString(1, txtLogin.getText());
                    st.setString(2, txtPass.getText());
                    ResultSet rs = st.executeQuery();
                    if (rs.next()) {
                        JOptionPane.showMessageDialog(this, "Login successful!!!");
                        Management obj = new Management(rs.getString(1));
                        obj.setVisible(true);
                    } else {
                        JOptionPane.showMessageDialog(this, "Account no exist !!!");
                    }
                } catch (Exception e) {
                }
            }
        } catch (NoSuchAlgorithmException ex) {
            ex.printStackTrace();
        }
    }//GEN-LAST:event_bntLoginActionPerformed

    private void jLabel6MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel6MouseClicked
        jDialog1.setVisible(true);
    }//GEN-LAST:event_jLabel6MouseClicked

    private void bntSignUpActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bntSignUpActionPerformed
        String regexemail = "^[A-Za-z0-9+_.-]+@(.+)$";
        String regaxPass = "^(.+)@(.+)$";
        Validation obj = new Validation();
        String user = txtUsername.getText();
        String pass = String.valueOf(txtPassword.getPassword());
        String cpass = txtCPassword.getText();
        String email = txtEmail.getText();
        if (!(user.equals("") || pass.equals("") || cpass.equals("") || email.equals(""))) {
            if (!(email.matches(regexemail))) {
                JOptionPane.showMessageDialog(this, "Email incorrent format!!!");
            } else if (!(Pattern.matches("[a-z0-9_-]{5,12}$", user))) {
                JOptionPane.showMessageDialog(this, "Username incorrent format!!!");
            } else if (!pass.matches(regaxPass) || !pass.equals(cpass)) {
                JOptionPane.showMessageDialog(this, "Password incorrent format!!!");
            } else {
                try {
                    Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/manage_coffee", "root", "admindeptrai@123");
                    PreparedStatement st = (PreparedStatement) conn.prepareStatement("insert into `signup` values(?,?,?,?)");

                    st.setString(1, user);
                    st.setString(2, obj.convertHashToString(pass));
                    st.setString(3, obj.convertHashToString(cpass));
                    st.setString(4, email);

                    if (st.executeUpdate() > 0) {
                        JOptionPane.showMessageDialog(this, "Sign up successful!!");
                        jDialog1.dispose();

                    } else {
                        JOptionPane.showMessageDialog(this, "Sign up fail!!");
                    }
                } catch (Exception e) {

                }
            }
        } else {
            JOptionPane.showMessageDialog(this, "Please complete the information!!");
        }


    }//GEN-LAST:event_bntSignUpActionPerformed

    private void txtPassActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtPassActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtPassActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {

        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Login().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> CbbPosition;
    private javax.swing.JButton bntCancle;
    private javax.swing.JButton bntLogin;
    private javax.swing.JButton bntSignUp;
    private javax.swing.JDialog jDialog1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPasswordField txtCPassword;
    private javax.swing.JTextField txtEmail;
    private javax.swing.JTextField txtLogin;
    private javax.swing.JPasswordField txtPass;
    private javax.swing.JPasswordField txtPassword;
    private javax.swing.JTextField txtUsername;
    // End of variables declaration//GEN-END:variables
}
