-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 30, 2020 at 06:20 AM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `manage_coffee`
--

-- --------------------------------------------------------

--
-- Table structure for table `bill`
--

CREATE TABLE `bill` (
  `ID` int(11) NOT NULL,
  `IDNV` varchar(15) DEFAULT NULL,
  `Mặc hàng` varchar(50) NOT NULL,
  `Số lượng` int(10) NOT NULL,
  `ĐVT` varchar(10) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `Giá` int(10) NOT NULL,
  `Thành tiền` int(15) NOT NULL,
  `Time` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `bill`
--

INSERT INTO `bill` (`ID`, `IDNV`, `Mặc hàng`, `Số lượng`, `ĐVT`, `Giá`, `Thành tiền`, `Time`) VALUES
(1, 'A01', 'Bia Tiger', 1, 'lon', 18000, 18000, '1585488924434'),
(2, 'A01', 'Bia Tiger', 1, 'lon', 18000, 18000, '1585488924434'),
(3, 'A01', 'Cappuccino', 1, 'ly', 30000, 30000, '1585488924434'),
(4, 'A01', 'Chapeau Banana', 2, 'lon', 40000, 80000, '1585488924434'),
(5, 'A01', 'Chè bưởi', 2, 'ly', 25000, 50000, '1585488924434'),
(6, 'A01', 'Chè bưởi', 2, 'ly', 25000, 50000, '1585488924434'),
(7, 'A02', 'Bia Tiger', 1, 'lon', 18000, 18000, '1585489745003'),
(8, 'A02', 'Cacao nóng', 1, 'ly', 18000, 18000, '1585489745003'),
(9, 'A02', 'Cappuccino', 1, 'ly', 30000, 30000, '1585489745003'),
(10, 'A02', 'Chè bưởi', 2, 'ly', 25000, 50000, '1585489745003'),
(11, 'A02', 'Nước Cam', 2, 'ly', 18000, 36000, '1585489745003'),
(12, 'A02', 'Nước Cam', 2, 'ly', 18000, 36000, '1585489745003'),
(13, 'A02', 'Cacao nóng', 2, 'ly', 18000, 36000, '1585489767370'),
(14, 'A02', 'Sinh tố Bơ', 2, 'ly', 25000, 50000, '1585489767370'),
(15, 'A02', 'Nước Cam', 2, 'ly', 18000, 36000, '1585489767370'),
(16, 'A02', 'Cafe Sữa', 2, 'ly', 20000, 40000, '1585489767370'),
(17, 'A02', 'Nước Chanh', 5, 'ly', 18000, 90000, '1585489767370'),
(18, 'A02', 'Nước Chanh', 5, 'ly', 18000, 90000, '1585489767370'),
(19, 'A02', 'Cappuccino', 5, 'ly', 30000, 150000, '1585489783810'),
(20, 'A02', 'Sinh tố Chanh dây', 5, 'ly', 25000, 125000, '1585489783810'),
(21, 'A02', 'Sinh tố Mãng Cầu', 5, 'ly', 25000, 125000, '1585489783810'),
(22, 'A02', 'Sinh tố Mãng Cầu', 5, 'ly', 25000, 125000, '1585489783810'),
(23, 'admin', 'Bia Tiger', 1, 'lon', 18000, 18000, '1585490839408'),
(24, 'admin', 'Cacao đá', 1, 'ly', 30000, 30000, '1585490839408'),
(25, 'admin', 'Heniken', 1, 'lon', 25000, 25000, '1585490839408'),
(26, 'admin', 'Heniken', 1, 'lon', 25000, 25000, '1585490839408'),
(27, 'A02', 'Bia Tiger', 1, 'long', 18000, 18000, '1585491016058'),
(28, 'A02', 'Cacao đá', 1, 'ly', 30000, 30000, '1585491016058'),
(29, 'A02', 'Cacao nóng', 1, 'ly', 18000, 18000, '1585491016058'),
(30, 'A02', 'Cacao nóng', 1, 'ly', 18000, 18000, '1585491016058'),
(31, 'A01', 'Bia Tiger', 1, 'long', 18000, 18000, '1585491146042'),
(32, 'A01', 'Cacao đá', 1, 'ly', 30000, 30000, '1585491146042'),
(33, 'A01', 'Cafe Đen', 1, 'ly', 18000, 18000, '1585491146042'),
(34, 'A01', 'Sinh tố Bơ', 1, 'ly', 25000, 25000, '1585491146042'),
(35, 'A01', 'Sinh tố Bơ', 1, 'ly', 25000, 25000, '1585491146042'),
(36, 'A01', 'Bia Tiger', 1, 'long', 18000, 18000, '1585491299931'),
(37, 'A01', 'Cacao nóng', 1, 'ly', 18000, 18000, '1585491299931'),
(38, 'A01', 'Cappuccino', 1, 'ly', 30000, 30000, '1585491299931'),
(39, 'A01', 'Cappuccino', 1, 'ly', 30000, 30000, '1585491299931');

-- --------------------------------------------------------

--
-- Table structure for table `informationnv`
--

CREATE TABLE `informationnv` (
  `ID` varchar(5) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `Họ và tên` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `Phone` varchar(20) NOT NULL,
  `Quê quán` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `Giới tính` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `Tài khoản` varchar(11) NOT NULL,
  `Mật khẩu` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `informationnv`
--

INSERT INTO `informationnv` (`ID`, `Họ và tên`, `Phone`, `Quê quán`, `Giới tính`, `Tài khoản`, `Mật khẩu`) VALUES
('A01', 'Huỳnh Nhật Minh', '0832511369', 'Cần Thơ', 'Nam', 'minhdz123', '123'),
('A02', 'Nguyễn Thị Hằng Ni', '0876665452', 'Vĩnh Long', 'Nữ', 'nixinhgai12', 'Ni123@321'),
('A03', 'Thầy Giao Ba', '0978677777', 'Cần Thơ', 'Nam', 'ba123', 'Ba123@321');

-- --------------------------------------------------------

--
-- Table structure for table `menu`
--

CREATE TABLE `menu` (
  `STT` int(10) NOT NULL,
  `Mặc hàng` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `ĐVT` varchar(20) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `Giá` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `menu`
--

INSERT INTO `menu` (`STT`, `Mặc hàng`, `ĐVT`, `Giá`) VALUES
(12, 'Bia Tiger', 'lon', 18000),
(8, 'Cacao đá', 'ly', 30000),
(7, 'Cacao nóng', 'ly', 18000),
(5, 'Cafe Đen', 'ly', 18000),
(6, 'Cafe Sữa', 'ly', 25000),
(9, 'Cappuccino', 'ly', 30000),
(23, 'Chapeau Apple', 'lon', 40000),
(22, 'Chapeau Banana', 'lon', 40000),
(18, 'Chè bưởi', 'ly', 25000),
(19, 'Chè Thái', 'ly', 25000),
(13, 'Heniken', 'lon', 25000),
(14, 'Nước Cam', 'ly', 18000),
(15, 'Nước Chanh', 'ly', 18000),
(17, 'Nước Dừa', 'trái', 20000),
(1, 'Sinh tố Bơ', 'ly', 25000),
(4, 'Sinh tố Chanh dây', 'ly', 25000),
(24, 'Sinh tố Đu đủ', 'ly', 26000),
(2, 'Sinh tố Mãng Cầu', 'ly', 25000),
(3, 'Sinh tố Nho', 'ly', 25000),
(10, 'StrongBow', 'lon', 20000),
(16, 'Trà Ô long', 'chai', 20000);

-- --------------------------------------------------------

--
-- Table structure for table `order`
--

CREATE TABLE `order` (
  `ID` int(11) NOT NULL,
  `IDNV` varchar(5) NOT NULL,
  `Số bàn` int(5) NOT NULL,
  `Mặt hàng` varchar(20) NOT NULL,
  `Số lượng` int(10) NOT NULL,
  `ĐVT` varchar(10) NOT NULL,
  `Giá` int(15) NOT NULL,
  `Thành tiền` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `order`
--

INSERT INTO `order` (`ID`, `IDNV`, `Số bàn`, `Mặt hàng`, `Số lượng`, `ĐVT`, `Giá`, `Thành tiền`) VALUES
(101, 'A01', 2, 'Cacao nóng', 1, 'ly', 18000, 18000),
(102, 'A01', 2, 'Cafe Đen', 1, 'ly', 18000, 18000),
(103, 'A01', 2, 'Cappuccino', 1, 'ly', 30000, 30000),
(104, 'A01', 2, 'Nước Cam', 1, 'ly', 18000, 18000),
(105, 'A01', 2, 'Cappuccino', 1, 'ly', 30000, 30000);

-- --------------------------------------------------------

--
-- Table structure for table `signup`
--

CREATE TABLE `signup` (
  `Username` varchar(20) NOT NULL,
  `Password` varchar(100) NOT NULL,
  `ConfirmPass` varchar(100) NOT NULL,
  `Email` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `signup`
--

INSERT INTO `signup` (`Username`, `Password`, `ConfirmPass`, `Email`) VALUES
('admin', '202cb962ac59075b964b07152d234b70', '25ce73c5b43bd5a8b32771be3a7989c3', 'admin12@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `store`
--

CREATE TABLE `store` (
  `ID` varchar(10) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `Tên Sản Phẩm` varchar(20) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `Số lượng` int(10) NOT NULL,
  `Đơn vị tính` varchar(10) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `Thành tiền` int(15) NOT NULL,
  `Nhà cung cấp` varchar(20) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `store`
--

INSERT INTO `store` (`ID`, `Tên Sản Phẩm`, `Số lượng`, `Đơn vị tính`, `Thành tiền`, `Nhà cung cấp`) VALUES
('1', 'Nước Suối', 12, 'thùng', 250000, 'Thái Hòa'),
('2', 'Sting', 12, 'lốc', 200000, 'Tây Sơn'),
('3', 'Heniken', 12, 'Thùng', 2000000, 'Thái Hòa'),
('4', 'Strongbow', 12, 'Thùng', 3000000, 'Thái Hòa'),
('5', 'Trà Ô long', 10, 'Lóc', 450000, 'Thái Hòa'),
('6', 'Trà Đào', 10, 'Thùng', 450000, 'Tây Sơn'),
('7', 'Nước Tăng Lực', 10, 'Lóc', 300000, 'Thái Hòa'),
('8', 'Trà Xanh', 12, 'Thùng', 3000000, 'Thái Hòa');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bill`
--
ALTER TABLE `bill`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `informationnv`
--
ALTER TABLE `informationnv`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `menu`
--
ALTER TABLE `menu`
  ADD PRIMARY KEY (`Mặc hàng`),
  ADD UNIQUE KEY `STT` (`STT`);

--
-- Indexes for table `order`
--
ALTER TABLE `order`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `signup`
--
ALTER TABLE `signup`
  ADD PRIMARY KEY (`Username`);

--
-- Indexes for table `store`
--
ALTER TABLE `store`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bill`
--
ALTER TABLE `bill`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- AUTO_INCREMENT for table `menu`
--
ALTER TABLE `menu`
  MODIFY `STT` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `order`
--
ALTER TABLE `order`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=106;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
