-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 22, 2020 at 04:27 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `manage_coffee`
--

-- --------------------------------------------------------

--
-- Table structure for table `bill`
--

CREATE TABLE `bill` (
  `ID` int(11) NOT NULL,
  `IDNV` varchar(15) DEFAULT NULL,
  `Mặc hàng` varchar(50) NOT NULL,
  `Số lượng` int(10) NOT NULL,
  `ĐVT` varchar(10) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `Giá` int(10) NOT NULL,
  `Thành tiền` int(15) NOT NULL,
  `Time` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `bill`
--

INSERT INTO `bill` (`ID`, `IDNV`, `Mặc hàng`, `Số lượng`, `ĐVT`, `Giá`, `Thành tiền`, `Time`) VALUES
(1, 'A02', 'Cappuccino', 1, 'ly', 30000, 30000, '1584882550745'),
(2, 'A01', 'Sinh tố Bơ', 2, 'ly', 25000, 50000, '1584886543169'),
(3, 'A01', 'Cafe Đen', 2, 'ly', 18000, 36000, '1584886543169'),
(4, 'A01', 'Cacao đá', 5, 'ly', 20000, 100000, '1584886543169'),
(5, 'A01', 'Cacao đá', 5, 'ly', 20000, 100000, '1584886543169'),
(6, 'A01', 'Sinh tố Mãng Cầu', 1, 'ly', 25000, 25000, '1584887116206'),
(7, 'A01', 'Cafe Đen', 1, 'ly', 18000, 18000, '1584887116206'),
(8, 'A01', 'Bia 333', 5, 'lon', 15000, 75000, '1584887116206'),
(9, 'A01', 'Bia 333', 5, 'lon', 15000, 75000, '1584887116206');

-- --------------------------------------------------------

--
-- Table structure for table `informationnv`
--

CREATE TABLE `informationnv` (
  `ID` varchar(5) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `Họ và tên` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `Phone` varchar(20) NOT NULL,
  `Quê quán` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `Giới tính` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `Tài khoản` varchar(11) NOT NULL,
  `Mật khẩu` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `informationnv`
--

INSERT INTO `informationnv` (`ID`, `Họ và tên`, `Phone`, `Quê quán`, `Giới tính`, `Tài khoản`, `Mật khẩu`) VALUES
('A01', 'Huỳnh Nhật Minh', '0832511369', 'Cần Thơ', 'Nam', 'minhdz123', '123'),
('A02', 'Nguyễn Thị Hằng Ni', '0876665452', 'Vĩnh Long', 'Nữ', 'nixinhgai12', 'Ni123@321'),
('A03', 'Nguyễn Thúy Vy', '0978677777', 'Sóc Trăng', 'Nam', 'vy123', 'Vy123@321');

-- --------------------------------------------------------

--
-- Table structure for table `management`
--

CREATE TABLE `management` (
  `Fullname` varchar(20) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `ID` varchar(20) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `Birthday` varchar(15) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `Gender` varchar(10) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `Address` varchar(20) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `CMT` varchar(15) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `Email` varchar(20) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `management`
--

INSERT INTO `management` (`Fullname`, `ID`, `Birthday`, `Gender`, `Address`, `CMT`, `Email`) VALUES
('Trần Thị Hòa An', 'B02', '11/08/2000', 'Nữ', 'Vĩnh Long', '372727377', 'an123@gmail.com'),
('Trần Na', 'B03', '21/12/2000', 'Nam', 'Sóc Trăng', '121212122', 'na123@gmail.com'),
('Tô Nguyệt Như', 'B04', '03/02/2000', 'Nữ', 'Cà Mau', '123242323', 'nhu123@gmail.com'),
('Bùi Thu Thảo', 'B07', '06/01/2000', 'Nữ', 'Quảng Ninh', '232435645', 'thao123@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `menu`
--

CREATE TABLE `menu` (
  `Mặc hàng` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `ĐVT` varchar(20) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `Giá` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `menu`
--

INSERT INTO `menu` (`Mặc hàng`, `ĐVT`, `Giá`) VALUES
('Sinh tố Bơ', 'ly', 25000),
('Sinh tố Mãng Cầu', 'ly', 25000),
('Sinh tố Nho', 'ly', 25000),
('Sinh tố Chanh dây', 'ly', 25000),
('Cafe Đen', 'ly', 18000),
('Cafe Sữa', 'ly', 20000),
('Cacao nóng', 'ly', 18000),
('Cacao đá', 'ly', 20000),
('Cappuccino', 'ly', 30000),
('StrongBow', 'lon', 20000),
('Bia 333', 'lon', 15000),
('Bia Tiger', 'long', 18000),
('Heniken', 'lon', 25000),
('Nước Cam', 'ly', 18000),
('Nước Chanh', 'ly', 18000),
('Trà Ô long', 'chai', 20000),
('Nước Dừa', 'trái', 20000),
('Chè bưởi', 'ly', 25000),
('Chè Thái', 'ly', 25000),
('Budweiser Bia Budweiser', 'lon', 50000),
('Corona Bia Corona Extra', 'lon', 50000),
('Chapeau Banana', 'lon', 40000),
('Chapeau Apple', 'lon', 40000);

-- --------------------------------------------------------

--
-- Table structure for table `signup`
--

CREATE TABLE `signup` (
  `Username` varchar(20) NOT NULL,
  `Password` varchar(100) NOT NULL,
  `ConfirmPass` varchar(100) NOT NULL,
  `Email` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `signup`
--

INSERT INTO `signup` (`Username`, `Password`, `ConfirmPass`, `Email`) VALUES
('admin12', '25ce73c5b43bd5a8b32771be3a7989c3', '25ce73c5b43bd5a8b32771be3a7989c3', 'admin12@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `store`
--

CREATE TABLE `store` (
  `ID` varchar(10) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `Tên Sản Phẩm` varchar(20) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `Số lượng` int(10) NOT NULL,
  `Đơn vị tính` varchar(10) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `Thành tiền` int(15) NOT NULL,
  `Nhà cung cấp` varchar(20) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `store`
--

INSERT INTO `store` (`ID`, `Tên Sản Phẩm`, `Số lượng`, `Đơn vị tính`, `Thành tiền`, `Nhà cung cấp`) VALUES
('1', 'Nước Suối', 12, 'thùng', 250000, 'Thái Hòa'),
('2', 'Sting', 12, 'lốc', 200000, 'Tây Sơn'),
('3', 'Heniken', 12, 'Thùng', 2000000, 'Thái Hòa'),
('4', 'Strongbow', 12, 'Thùng', 3000000, 'Thái Hòa'),
('5', 'Trà Ô long', 10, 'Lóc', 450000, 'Thái Hòa'),
('6', 'Trà Đào', 10, 'Thùng', 450000, 'Tây Sơn'),
('7', 'Nước Tăng Lực', 10, 'Lóc', 300000, 'Thái Hòa');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bill`
--
ALTER TABLE `bill`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `informationnv`
--
ALTER TABLE `informationnv`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `management`
--
ALTER TABLE `management`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `signup`
--
ALTER TABLE `signup`
  ADD PRIMARY KEY (`Username`);

--
-- Indexes for table `store`
--
ALTER TABLE `store`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bill`
--
ALTER TABLE `bill`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
